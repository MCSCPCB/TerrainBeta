import { BLOCKS, BIOME_IDS, DEFAULT_BIOME_SURFACE_CONFIG } from "../../alphaClassic/index.js";
import {
  BEDROCK_BLOCK_MAP,
  BLOCK_ROLE_IDS,
  DEFAULT_BLOCK_PALETTE,
} from "../../alphaClassic/world/blocks.js";
import { AlphaClassicBedrockGenerator } from "../../alphaClassic/runtime/bedrockGenerator.js";
import { createGeneratorPalette } from "./palette.js";

const ALPHA_CLASSIC_DIMENSIONS = Object.freeze({
  chunkSize: 16,
  chunkHeight: 128,
  minWorldY: 0,
});
const ALPHA_CLASSIC_RUNTIME_PROFILE = Object.freeze({
  initializationCompletionMode: "center_landing",
  backgroundLookaheadChunks: 3,
});

export function createAlphaClassicWorldGenerator(config) {
  const palette = createGeneratorPalette({
    generatorId: "alphaClassic",
    biomeIds: BIOME_IDS,
    defaultBlockPalette: DEFAULT_BLOCK_PALETTE,
    blockRoleIds: BLOCK_ROLE_IDS,
    defaultSurfaceConfig: DEFAULT_BIOME_SURFACE_CONFIG,
    blockPaletteOverrides: config.blockPalette,
    surfacePaletteOverrides: config.surfacePalette,
  });

  return {
    id: "alphaClassic",
    storageKey: config.storageKey ?? "alphaClassicGeneratedChunks",
    dimensions: ALPHA_CLASSIC_DIMENSIONS,
    runtimeProfile: {
      ...ALPHA_CLASSIC_RUNTIME_PROFILE,
      ...config.runtimeProfile,
    },
    blocks: BLOCKS,
    defaultBlockTypeMap: BEDROCK_BLOCK_MAP,
    blockPalette: palette.blockPalette,
    blockTypeMap: palette.blockTypeMap,
    generator: new AlphaClassicBedrockGenerator(
      config.seed,
      {
        ...config.options,
        farlandsCoordinate: config.farlandsCoordinate,
        surfacePalette: palette.surfacePalette,
      },
    ),
  };
}

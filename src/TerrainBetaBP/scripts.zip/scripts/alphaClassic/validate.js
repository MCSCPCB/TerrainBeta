import { AlphaClassicBedrockGenerator } from "./runtime/bedrockGenerator.js";

function assert(condition, message) {
  if (!condition) {
    throw new Error(message);
  }
}

function arraysEqual(left, right) {
  if (left.length !== right.length) {
    return false;
  }
  for (let index = 0; index < left.length; index += 1) {
    if (left[index] !== right[index]) {
      return false;
    }
  }
  return true;
}

function testDeterministicChunk() {
  const generator = new AlphaClassicBedrockGenerator("123456789");
  const first = generator.generateChunk(0, 0);
  const second = generator.generateChunk(0, 0);
  assert(arraysEqual(first.blocks, second.blocks), "generateChunk should be deterministic");
  assert(arraysEqual(first.heightmap, second.heightmap), "heightmap should be deterministic");
}

function testBackgroundTerrainParity() {
  const generator = new AlphaClassicBedrockGenerator("123456789");
  const sync = generator.generateTerrainChunk(3, -2);
  const session = generator.createBackgroundTerrainSession(3, -2);
  while (!session.complete) {
    generator.advanceBackgroundTerrainSession(session);
  }
  assert(arraysEqual(sync.blocks, session.terrainChunk.blocks), "background terrain blocks mismatch");
  assert(arraysEqual(sync.heightmap, session.terrainChunk.heightmap), "background terrain heightmap mismatch");
}

function testBackgroundDecorationParity() {
  const generator = new AlphaClassicBedrockGenerator("123456789");
  const terrain = generator.generateTerrainChunk(-1, 4);
  const sync = generator.decorateTerrainChunk(terrain);
  const session = generator.createBackgroundDecorationSession(terrain);
  while (!session.complete) {
    generator.advanceBackgroundDecorationSession(session);
  }
  assert(arraysEqual(sync.blocks, session.decoratedBlocks), "background decoration blocks mismatch");
}

function testSnowWorldSmoke() {
  const generator = new AlphaClassicBedrockGenerator("123456789", { snowCovered: true });
  const chunk = generator.generateChunk(0, 0);
  assert(chunk.blocks.length === 32768, "snow world chunk size mismatch");
}

function main() {
  testDeterministicChunk();
  testBackgroundTerrainParity();
  testBackgroundDecorationParity();
  testSnowWorldSmoke();
  console.log("alphaClassic validate: PASS");
}

main();
